// var config = {
//     "apiKey": "2BYH7ZQ2CHB3MA5GFPEPI12FQV9AD3UEJN",
//     "keyword": "Axie",
//     "totalSupply": 100000000000,
//     "maxHolders": 30,
//     "maxTransfers": 350,
//     "compilerVersion": "0.0.1"
// }
var config = {
    "apiKey": "2BYH7ZQ2CHB3MA5GFPEPI12FQV9AD3UEJN",
    "keyword": "Axie",
    "totalSupply": 100000000000,
    "maxHolders": 30,
    "compilerVersion": "0.0.1"
}
exports.config = config;